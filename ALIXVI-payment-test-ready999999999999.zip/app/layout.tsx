import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ALIXVI — Turn your script into a movie",
  description: "Create AI-powered movies and short videos from a script.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
