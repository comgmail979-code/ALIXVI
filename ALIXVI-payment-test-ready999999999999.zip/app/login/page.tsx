"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Clapperboard, LoaderCircle } from "lucide-react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const [mode, setMode] = useState<"signup" | "login">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const router = useRouter();

  async function submit(event: FormEvent) {
    event.preventDefault(); setBusy(true); setMessage("");
    try {
      const supabase = createSupabaseBrowserClient();
      const result = mode === "signup"
        ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=/account` } })
        : await supabase.auth.signInWithPassword({ email, password });
      if (result.error) throw result.error;
      if (mode === "signup" && !result.data.session) {
        setMessage("Check your email to confirm your account. After confirmation, sign in to access your 2 free trial videos.");
      } else { router.push("/#studio"); router.refresh(); }
    } catch (error) {
      setMessage(new URLSearchParams(window.location.search).get("auth") === "callback-error" ? "Email confirmation could not be completed. Please try signing in or request a new confirmation email." : error instanceof Error ? error.message : "Could not complete account request.");
    } finally { setBusy(false); }
  }

  return <main className="auth-page"><nav className="nav wrap"><Link className="brand" href="/"><span className="brand-mark"><Clapperboard size={20}/></span> ALIXVI<span className="brand-dot">.</span></Link><Link className="text-link" href="/">Back to studio ↗</Link></nav><section className="auth-card"><div className="eyebrow">YOUR CREATOR ACCOUNT</div><h1>{mode === "signup" ? "Start creating." : "Welcome back."}</h1><p className="auth-sub">{mode === "signup" ? "Create a free account and get 2 video generations to try ALIXVI." : "Sign in to continue creating with ALIXVI."}</p><form onSubmit={submit}><label className="field-label" htmlFor="email">EMAIL ADDRESS</label><input id="email" type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/><label className="field-label" htmlFor="password">PASSWORD</label><input id="password" type="password" autoComplete={mode === "signup" ? "new-password" : "current-password"} minLength={8} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/><button className="button primary auth-submit" disabled={busy}>{busy ? <><LoaderCircle className="spin" size={17}/> Please wait…</> : mode === "signup" ? "Create free account" : "Sign in"}</button></form>{message && <p className="auth-message">{message}</p>}<p className="auth-switch">{mode === "signup" ? "Already have an account?" : "New to ALIXVI?"} <button onClick={()=>{setMode(mode === "signup" ? "login" : "signup");setMessage("")}}>{mode === "signup" ? "Sign in" : "Create account"}</button></p><p className="auth-terms">By continuing, you agree to use ALIXVI responsibly. Terms and privacy pages will be published before public launch.</p></section></main>;
}
