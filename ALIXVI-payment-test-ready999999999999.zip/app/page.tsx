"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Clapperboard, Film, WandSparkles, Download, Play, Sparkles, ChevronDown, Menu, X, LoaderCircle, UserRound } from "lucide-react";

type Job = { id: string; status: string; message: string; videoUrl?: string; sceneNumber: number };
type Account = { authenticated: boolean; email?: string; trialVideosRemaining: number; paidVideoCredits: number; subscriptionStatus?: string };


export default function Home() {
  const [mode, setMode] = useState<"movie" | "short">("movie");
  const [script, setScript] = useState("");
  const [style, setStyle] = useState("Cinematic realism");
  const [ratio, setRatio] = useState("16:9");
  const [busy, setBusy] = useState(false);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [currentScene, setCurrentScene] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [account, setAccount] = useState<Account | null>(null);

  async function refreshAccount() {
    try {
      const response = await fetch("/api/account", { cache: "no-store" });
      const data = await response.json();
      if (response.ok && data.authenticated !== undefined) setAccount(data);

    } catch { /* The studio remains viewable if account services are not configured. */ }
  }
  useEffect(() => { refreshAccount(); }, []);

  function makeScenes(text: string) {
    const paragraphs = text.split(/\n\s*\n/).map(part => part.trim()).filter(Boolean);
    const source = paragraphs.flatMap(part => part.split(/(?<=[.!?])\s+/).filter(Boolean));
    const chunks: string[] = [];
    let current = "";
    for (const part of source) {
      if ((current + " " + part).trim().length > 650 && current) {
        chunks.push(current.trim());
        current = part;
      } else {
        current = `${current} ${part}`.trim();
      }
    }
    if (current) chunks.push(current.trim());
    return chunks.slice(0, 12);
  }

  async function waitForScene(id: string, sceneNumber: number): Promise<string> {
    for (let attempt = 0; attempt < 90; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      const response = await fetch(`/api/status/${encodeURIComponent(id)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok || data.status === "FAILED" || data.status === "SETUP") {
        throw new Error(data.message || `Scene ${sceneNumber} failed.`);
      }
      setJobs(previous => previous.map(item => item.sceneNumber === sceneNumber
        ? { ...item, status: data.status, message: data.message, videoUrl: data.videoUrl }
        : item));
      if (data.status === "COMPLETED" && data.videoUrl) return data.videoUrl;
    }
    throw new Error(`Scene ${sceneNumber} is taking longer than expected. You can retry it later.`);
  }

  async function generate() {
    if (!script.trim() || busy) return;
    const scenes = mode === "short" ? [script.trim()] : makeScenes(script);
    if (!scenes.length) return;
    setBusy(true);
    setJobs(scenes.map((_, index) => ({
      id: `scene-${index + 1}`, sceneNumber: index + 1, status: "PENDING", message: "Waiting to start…",
    })));
    setCurrentScene(0);
    let activeScene = 0;
    try {
      for (let index = 0; index < scenes.length; index++) {
        const sceneNumber = index + 1;
        activeScene = sceneNumber;
        setCurrentScene(sceneNumber);
        setJobs(previous => previous.map(item => item.sceneNumber === sceneNumber
          ? { ...item, status: "SUBMITTING", message: "Sending scene to the video engine…" }
          : item));
        const response = await fetch("/api/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            script: scenes[index], storyContext: script.slice(0, 4000), style, ratio,
            sceneNumber, sceneCount: scenes.length,
          }),
        });
        const data = await response.json();
        if (!response.ok || !data.id) {
          if (data.code === "AUTH_REQUIRED") window.location.href = "/login";
          throw new Error(data.error || "Could not start scene generation.");
        }
        await refreshAccount();
        setJobs(previous => previous.map(item => item.sceneNumber === sceneNumber
          ? { ...item, id: data.id, status: data.status || "IN_QUEUE", message: "Scene added to the render queue." }
          : item));
        const videoUrl = await waitForScene(data.id, sceneNumber);
        setJobs(previous => previous.map(item => item.sceneNumber === sceneNumber
          ? { ...item, status: "COMPLETED", videoUrl, message: "Scene is ready." }
          : item));
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Something went wrong.";
      setJobs(previous => previous.map(item => item.sceneNumber === activeScene
        ? { ...item, status: "FAILED", message }
        : item));
    } finally {
      setBusy(false);
    }
  }

  const completedScenes = jobs.filter(item => item.status === "COMPLETED" && item.videoUrl).length;
  const sceneCount = mode === "short" ? 1 : makeScenes(script).length;


  return (
    <>
    <a href="/movie-editor" className="fixed bottom-5 right-5 z-50 rounded-full border border-white/20 bg-black px-5 py-3 text-sm font-semibold text-white shadow-xl">Open Movie Editor →</a>
    <main>
      <nav className="nav wrap">
        <a className="brand" href="#"><span className="brand-mark"><Clapperboard size={20}/></span> ALIXVI<span className="brand-dot">.</span></a>
        <div className="nav-links"><a href="#studio">Studio</a><a href="#pricing">Pricing</a><a href="#how">How it works</a><a href="#features">Features</a></div>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X/> : <Menu/>}</button>
        <div className="nav-actions"><a className="account-link" href={account?.authenticated ? "/account" : "/login"}><UserRound size={14}/>{account?.authenticated ? "My account" : "Sign in"}</a><a className="nav-cta" href="#studio">Start creating <span>↗</span></a></div>
        {menuOpen && <div className="mobile-menu"><a href="#studio" onClick={()=>setMenuOpen(false)}>Studio</a><a href="#pricing" onClick={()=>setMenuOpen(false)}>Pricing</a><a href="#how" onClick={()=>setMenuOpen(false)}>How it works</a><a href="#features" onClick={()=>setMenuOpen(false)}>Features</a></div>}
      </nav>

      <section className="hero wrap">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse"/> YOUR STORY. YOUR SCREEN.</div>
          <h1>From script<br/>to <em>cinema.</em></h1>
          <p className="hero-sub">Your imagination deserves the big screen. Turn a simple idea or a complete script into cinematic AI videos with ALIXVI.</p>
          <div className="hero-actions"><a className="button primary" href="#studio">Create your video <WandSparkles size={17}/></a><a className="text-link" href="#how"><Play size={15}/> See how it works</a></div>
          <div className="hero-proof"><div className="avatars"><i>A</i><i>L</i><i>X</i></div><span>Made for storytellers everywhere</span></div>
          <div className="trial-note"><Sparkles size={15}/> New creators get 2 free video generations.</div>
        </div>
        <div className="hero-art">
          <div className="art-glow"/>
          <div className="poster">
            <div className="poster-top"><span>ALIXVI ORIGINALS</span><span>001 / 2026</span></div>
            <div className="poster-scene"><div className="moon"/><div className="silhouette s1"/><div className="silhouette s2"/><div className="horizon"/></div>
            <div className="poster-title">THE LAST<br/><i>HORIZON</i></div>
            <div className="poster-bottom"><span>A STORY WAITING TO BE TOLD</span><span>▶ 4K</span></div>
          </div>
          <div className="floating-tag tag-one"><Sparkles size={14}/> AI SCENE BUILDER</div>
          <div className="floating-tag tag-two"><Film size={14}/> YOUR NEXT BIG STORY</div>
        </div>
      </section>

      <section className="studio-section" id="studio">
        <div className="wrap">
          <div className="section-heading"><div><div className="eyebrow">THE CREATIVE STUDIO</div><h2>What will you <em>create?</em></h2></div><span className="section-note">One script is all it takes.</span></div>
          <div className="studio-grid">
            <div className="editor-card">
              <div className="card-top"><div><span className="step">01</span><strong>Start with your script</strong></div><span className="live-pill">● READY</span></div>
              <div className="mode-switch">
                <button className={mode === "movie" ? "selected" : ""} onClick={() => setMode("movie")}><Film size={16}/> Full movie</button>
                <button className={mode === "short" ? "selected" : ""} onClick={() => setMode("short")}><Play size={16}/> Short video</button>
              </div>
              <label className="field-label" htmlFor="script">YOUR SCRIPT OR STORY</label>
              <textarea id="script" value={script} onChange={e=>setScript(e.target.value)} placeholder={"Paste your script here…\n\nExample: A young pilot discovers a mysterious signal coming from a forgotten planet. As she investigates, she uncovers a secret that could change humanity forever."}/>
              <div className="editor-foot"><span>{script.trim().length} characters · {mode === "movie" ? `${sceneCount} scenes detected` : "1 clip"}</span><button onClick={()=>setScript("")}>Clear script</button></div>
              <div className="setting engine-setting"><label className="field-label">VIDEO ENGINE</label><div className="provider-note"><strong>MiniMax H3 Max</strong><span>via fal.ai · 768P · 8-second scenes</span></div></div>
              <div className="settings-row">
                <div className="setting"><label className="field-label">VISUAL STYLE</label><div className="select-wrap"><select value={style} onChange={e=>setStyle(e.target.value)}><option>Cinematic realism</option><option>Anime</option><option>3D animation</option><option>Documentary</option><option>Fantasy</option><option>Comic book</option></select><ChevronDown size={15}/></div></div>
                <div className="setting"><label className="field-label">ASPECT RATIO</label><div className="select-wrap"><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>16:9</option><option>9:16</option><option>1:1</option></select><ChevronDown size={15}/></div></div>
              </div>
              {mode === "movie" && <div className="duration-setting"><label className="field-label">CURRENT BATCH LIMIT</label><div className="provider-note"><strong>Up to 12 scenes</strong><span>8 seconds per clip · up to 96 seconds total</span></div></div>}
              <button className="button generate" disabled={!script.trim() || busy} onClick={generate}>{busy ? <><LoaderCircle className="spin" size={18}/> Starting…</> : <>Generate {mode === "movie" ? "scenes" : "short video"} <WandSparkles size={18}/></>}</button>
              {account?.authenticated ? <p className="credit-balance">{account.trialVideosRemaining} free videos left · {account.paidVideoCredits} paid credits</p> : <p className="fine-print"><Link href="/login">Create a free account</Link> to claim your 2 trial videos.</p>}
              <p className="fine-print">Generation requires a connected video AI provider. Your script is sent only when you click generate.</p>
              {mode === "movie" && <p className="fine-print">ALIXVI breaks the script into up to 12 scenes and renders each as an 8-second clip. Each scene uses one video credit, so a 12-scene movie needs 12 credits. This build returns separate scene clips; import your completed scenes into Movie Editor to combine them into one MP4.</p>}
              <p className="fine-print">Provider rendering uses paid fal.ai credits. MiniMax H3 Max is currently priced from about US$0.08 per second at 768P; actual cost depends on the provider's current rates and settings.</p>
              {jobs.length > 0 && <div className="render-progress"><div className="progress-heading"><strong>{busy ? `Rendering scene ${currentScene} of ${jobs.length}` : completedScenes === jobs.length ? "All scenes rendered" : "Render results"}</strong><span>{completedScenes}/{jobs.length} ready</span></div><div className="progress-track"><span style={{width: `${jobs.length ? completedScenes / jobs.length * 100 : 0}%`}}/></div>{jobs.map(item => <div className="scene-result" key={item.sceneNumber}><div><strong>Scene {String(item.sceneNumber).padStart(2,"0")}</strong><span>{item.message}</span></div><span className={`scene-status ${item.status === "COMPLETED" ? "done" : item.status === "FAILED" ? "failed" : ""}`}>{item.status}</span>{item.videoUrl && <a href={item.videoUrl} target="_blank" rel="noreferrer">Open MP4 ↗</a>}</div>)}</div>}
            </div>
            <div className="preview-card">
              <div className="preview-top"><span>YOUR PREVIEW</span><span className="preview-status"><span/> WAITING FOR SCRIPT</span></div>
              <div className="preview-screen"><div className="preview-orbit o1"/><div className="preview-orbit o2"/><div className="preview-center"><Clapperboard size={34}/><span>Your story starts here</span><small>AI VIDEO PREVIEW</small></div><div className="preview-corner">ALIXVI / STUDIO</div></div>
              <div className="preview-meta"><div><span>OUTPUT FORMAT</span><strong>MP4 VIDEO</strong></div><div><span>VISUAL QUALITY</span><strong>AI ENHANCED</strong></div><div><span>YOUR PROJECT</span><strong>{mode === "movie" ? "FEATURE FILM" : "SHORT FORM"}</strong></div></div>
            </div>
          </div>
        </div>
      </section>

      <section className="pricing-section wrap" id="pricing">
        <div className="eyebrow">SIMPLE MONTHLY PRICING</div><h2>Start free. <em>Grow your stories.</em></h2>
        <p className="pricing-intro">Try ALIXVI with two free video generations. When you are ready for more, monthly membership starts at 3,000 RWF.</p>
        <div className="pricing-grid">
          <article className="price-card"><span className="price-kicker">NEW CREATOR</span><h3>Free</h3><div className="price-amount">0 <small>RWF</small></div><p>Try the studio before subscribing.</p><ul><li>2 free video generations</li><li>Short video and scene testing</li><li>No payment details to start</li></ul><Link className="price-button secondary-price" href="/login">Create free account</Link></article>
          <article className="price-card featured-price"><span className="price-kicker">CREATOR MONTHLY</span><h3>Starter</h3><div className="price-amount">3,000 <small>RWF / month</small></div><p>For creators ready to keep making videos.</p><ul><li>Monthly membership</li><li>Video credits for AI generation</li><li>Project history and downloads</li><li>Cancel according to plan terms</li></ul><Link className="price-button" href="/login">Create free account</Link><small className="price-disclaimer">Pay with Rwanda Mobile Money (MTN / Airtel) or Visa / Mastercard. Monthly video-credit allowance will be shown before checkout.</small></article>
        </div>
      </section>

      <section className="how-section wrap" id="how"><div className="eyebrow">SIMPLE BY DESIGN</div><h2>Three steps. <em>One story.</em></h2><div className="steps"><article><span>01</span><div className="step-icon"><Film/></div><h3>Write or paste</h3><p>Bring a script, a scene, or just the story idea in your head.</p></article><article><span>02</span><div className="step-icon"><WandSparkles/></div><h3>Let AI create</h3><p>Turn your words into scenes, visuals, motion, and sound.</p></article><article><span>03</span><div className="step-icon"><Download/></div><h3>Export your video</h3><p>Review your creation and export the finished video when ready.</p></article></div></section>

      <section className="features-section" id="features"><div className="wrap features-inner"><div><div className="eyebrow">BUILT FOR BIG IDEAS</div><h2>Your studio.<br/><em>No limits.</em></h2><p>From a vertical social clip to a story-driven movie, ALIXVI gives creators one place to bring ideas to life.</p></div><div className="feature-list"><div><span>✳</span><section><strong>Two creative formats</strong><p>Make short-form videos or build a longer movie from your script.</p></section></div><div><span>◈</span><section><strong>Your visual direction</strong><p>Choose a look and aspect ratio to shape the result.</p></section></div><div><span>↗</span><section><strong>Made to grow</strong><p>A modular foundation ready for accounts, projects, billing, and more.</p></section></div></div></div></section>
      <footer className="footer wrap"><a className="brand" href="#"><span className="brand-mark"><Clapperboard size={18}/></span> ALIXVI<span className="brand-dot">.</span></a><span>MAKE SOMETHING WORTH WATCHING.</span><span>© 2026 ALIXVI</span></footer>
    </main>
    </>
  );
}
