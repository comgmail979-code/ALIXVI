import { NextRequest, NextResponse } from "next/server";
import { verifyAndApplyFlutterwavePayment } from "@/lib/payments/flutterwave";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const status = request.nextUrl.searchParams.get("status");
  const txRef = request.nextUrl.searchParams.get("tx_ref") ?? undefined;
  const transactionId = request.nextUrl.searchParams.get("transaction_id");
  const base = new URL("/account", request.url);
  if (status !== "successful" || !txRef || !transactionId) {
    base.searchParams.set("payment", "not-completed");
    return NextResponse.redirect(base);
  }
  try {
    await verifyAndApplyFlutterwavePayment(transactionId, txRef);
    base.searchParams.set("payment", "success");
  } catch (error) {
    console.error("ALIXVI payment callback verification failed", error);
    base.searchParams.set("payment", "pending");
  }
  return NextResponse.redirect(base);
}
