import { NextRequest, NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { verifyAndApplyFlutterwavePayment } from "@/lib/payments/flutterwave";

export const runtime = "nodejs";

function safeEqual(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

export async function POST(request: NextRequest) {
  const secretHash = process.env.FLW_SECRET_HASH;
  const rawBody = await request.text();
  const suppliedSignature = request.headers.get("flutterwave-signature") ?? "";
  if (!secretHash || !suppliedSignature) {
    return NextResponse.json({ error: "Invalid webhook signature." }, { status: 401 });
  }

  // Current Flutterwave webhook docs specify HMAC-SHA256 over the exact raw body,
  // encoded as base64 and sent in the flutterwave-signature header.
  const expectedSignature = createHmac("sha256", secretHash).update(rawBody).digest("base64");
  if (!safeEqual(expectedSignature, suppliedSignature)) {
    return NextResponse.json({ error: "Invalid webhook signature." }, { status: 401 });
  }

  try {
    const payload = JSON.parse(rawBody);
    const data = payload?.data;
    const event = payload?.type ?? payload?.event;
    const txRef = typeof data?.tx_ref === "string"
      ? data.tx_ref
      : typeof data?.meta?.alixvi_tx_ref === "string"
        ? data.meta.alixvi_tx_ref
        : typeof data?.reference === "string" ? data.reference : undefined;
    const successful = data?.status === "successful" || data?.status === "succeeded";

    if (event === "charge.completed" && successful && data?.id && txRef) {
      // Always re-verify against Flutterwave's API before activating membership.
      await verifyAndApplyFlutterwavePayment(String(data.id), txRef);
      return NextResponse.json({ received: true });
    }

    const email = data?.customer?.email ?? data?.email;
    const admin = createSupabaseAdminClient();
    if (event === "charge.completed" && !successful) {
      if (txRef) {
        await admin.from("alixvi_payments")
          .update({ status: "failed" })
          .eq("checkout_reference", txRef)
          .eq("status", "pending");
      }
      if (data?.payment_type === "card" && email) {
        await admin.rpc("set_flutterwave_subscription_state", { p_customer_email: email, p_state: "past_due" });
      }
    }
    if ((event === "subscription.cancelled" || event === "subscription.canceled") && email) {
      await admin.rpc("set_flutterwave_subscription_state", { p_customer_email: email, p_state: "cancelled" });
    }
    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("ALIXVI Flutterwave webhook failed", error);
    return NextResponse.json({ error: "Webhook processing failed." }, { status: 500 });
  }
}
