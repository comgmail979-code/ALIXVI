import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const supabase = createSupabaseServerClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user?.email) {
      return NextResponse.json({ error: "Please sign in with an email before subscribing." }, { status: 401 });
    }

    const body = await request.json().catch(() => ({}));
    const method = body?.method;
    if (method !== "card" && method !== "mobilemoneyrwanda") {
      return NextResponse.json({ error: "Choose Visa/Mastercard or Rwanda Mobile Money." }, { status: 400 });
    }

    const secret = process.env.FLW_SECRET_KEY;
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
    const amount = Number(process.env.ALIXVI_MONTHLY_PRICE_RWF ?? "3000");
    if (!secret || !siteUrl) {
      return NextResponse.json({ error: "Payments are not configured yet. Please try again later." }, { status: 503 });
    }
    if (!Number.isInteger(amount) || amount !== 3000) {
      return NextResponse.json({ error: "The monthly price is not configured correctly." }, { status: 503 });
    }

    const txRef = `ALIXVI-${randomUUID()}`;
    const admin = createSupabaseAdminClient();
    const { error: insertError } = await admin.from("alixvi_payments").insert({
      user_id: user.id,
      provider: "flutterwave",
      amount_rwf: amount,
      currency: "RWF",
      status: "pending",
      checkout_reference: txRef,
    });
    if (insertError) throw insertError;

    const payload: Record<string, unknown> = {
      tx_ref: txRef,
      amount: String(amount),
      currency: "RWF",
      redirect_url: `${siteUrl.replace(/\/$/, "")}/api/payments/callback`,
      customer: { email: user.email, name: user.user_metadata?.full_name ?? user.email },
      payment_options: method === "card" ? "card" : "mobilemoneyrwanda",
      customizations: {
        title: "ALIXVI Creator Monthly",
        description: "One month of ALIXVI membership",
      },
      meta: { alixvi_user_id: user.id, alixvi_plan: "monthly", alixvi_tx_ref: txRef },
      session_duration: 30,
      max_retry_attempt: 3,
    };

    const checkoutResponse = await fetch("https://api.flutterwave.com/v3/payments", {
      method: "POST",
      headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      cache: "no-store",
    });
    const checkout = await checkoutResponse.json();
    const checkoutUrl = checkout?.data?.link;
    if (!checkoutResponse.ok || checkout?.status !== "success" || typeof checkoutUrl !== "string" || !checkoutUrl.startsWith("https://checkout.flutterwave.com/")) {
      await admin.from("alixvi_payments").update({ status: "failed" }).eq("checkout_reference", txRef).eq("status", "pending");
      return NextResponse.json({ error: "Flutterwave could not create checkout. Confirm that cards and Rwanda Mobile Money are enabled on your merchant account." }, { status: 502 });
    }

    return NextResponse.json({ checkoutUrl, txRef, renewal: "manual" });
  } catch (error) {
    console.error("ALIXVI checkout error", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not start checkout." }, { status: 500 });
  }
}
