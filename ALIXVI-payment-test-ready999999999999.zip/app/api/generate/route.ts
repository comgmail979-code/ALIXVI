import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";

const MODEL = "minimax/h3-max/text-to-video";
const ALLOWED_RATIOS = new Set(["16:9", "9:16", "1:1"]);
const ALLOWED_STYLES = new Set([
  "Cinematic realism", "Anime", "3D animation", "Documentary", "Fantasy", "Comic book",
]);

type GenerateBody = {
  script?: unknown;
  storyContext?: unknown;
  style?: unknown;
  ratio?: unknown;
  sceneNumber?: unknown;
  sceneCount?: unknown;
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as GenerateBody;
    if (typeof body.script !== "string" || !body.script.trim()) {
      return NextResponse.json({ error: "Add a scene description before generating." }, { status: 400 });
    }
    if (body.script.length > 5000) {
      return NextResponse.json({ error: "Each scene description must be 5,000 characters or fewer." }, { status: 400 });
    }

    const key = process.env.FAL_KEY;
    if (!key) {
      return NextResponse.json({
        error: "Video generation is not connected yet. Add your fal.ai API key as FAL_KEY in .env.local, then restart ALIXVI. Keep the key on the server; never put it in browser code.",
      }, { status: 503 });
    }

    const supabase = createSupabaseServerClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Create a free ALIXVI account or sign in to use your video credits.", code: "AUTH_REQUIRED" }, { status: 401 });
    }

    const style = typeof body.style === "string" && ALLOWED_STYLES.has(body.style)
      ? body.style : "Cinematic realism";
    const ratio = typeof body.ratio === "string" && ALLOWED_RATIOS.has(body.ratio)
      ? body.ratio : "16:9";
    const sceneNumber = Number.isInteger(body.sceneNumber) ? Number(body.sceneNumber) : 1;
    const sceneCount = Number.isInteger(body.sceneCount) ? Number(body.sceneCount) : 1;

    const prompt = [
      `Create one coherent 8-second cinematic video shot for scene ${sceneNumber} of ${sceneCount}.`,
      `Visual style: ${style}. Aspect ratio: ${ratio}.`,
      "Keep the same named characters, clothing, age, hair, and key props exactly as described. Do not add subtitles, captions, logos, watermarks, or title cards.",
      "Use a clear subject, deliberate camera movement, believable physical motion, cinematic lighting, and a visually readable beginning, middle, and end.",
      "STORY / CHARACTER CONTINUITY REFERENCE:",
      typeof body.storyContext === "string" ? body.storyContext.slice(0, 4000) : body.script.trim(),
      "CURRENT SCENE TO RENDER:",
      body.script.trim(),
    ].join("\n\n");

    const admin = createSupabaseAdminClient();
    const { data: credit, error: creditError } = await admin.rpc("consume_video_credit", { p_user_id: user.id });
    if (creditError) return NextResponse.json({ error: "Could not verify your video credits. Please try again." }, { status: 503 });
    if (!credit?.allowed) {
      return NextResponse.json({
        error: credit?.reason === "credits_required"
          ? "Your 2 free videos have been used. Choose an ALIXVI monthly plan starting at 3,000 RWF to continue."
          : "Please sign in to use ALIXVI.",
        code: credit?.reason === "credits_required" ? "CREDITS_REQUIRED" : "AUTH_REQUIRED",
      }, { status: credit?.reason === "credits_required" ? 402 : 401 });
    }

    const endpoint = `https://queue.fal.run/${MODEL}`;
    let upstream: Response;
    try {
      upstream = await fetch(endpoint, {
        method: "POST",
        headers: { Authorization: `Key ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          aspect_ratio: ratio,
          resolution: "768P",
          duration: 8,
          prompt_expansion_mode: "balanced",
        }),
        cache: "no-store",
      });
    } catch (error) {
      await admin.rpc("refund_video_credit", { p_user_id: user.id, p_source: credit.source });
      throw error;
    }
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok || !data.request_id) {
      await admin.rpc("refund_video_credit", { p_user_id: user.id, p_source: credit.source });
      const detail = data.detail || data.error || data.message || `fal.ai returned HTTP ${upstream.status}.`;
      return NextResponse.json({ error: String(detail) }, { status: 502 });
    }

    const { error: jobError } = await admin.from("generation_jobs").insert({
      user_id: user.id,
      provider_request_id: data.request_id,
      model: MODEL,
      scene_number: sceneNumber,
      credit_source: credit.source,
      status: data.status || "IN_QUEUE",
    });
    if (jobError) {
      await admin.rpc("refund_video_credit", { p_user_id: user.id, p_source: credit.source });
      return NextResponse.json({ error: "The video job could not be saved. Your credit has been restored; please retry." }, { status: 503 });
    }

    return NextResponse.json({
      id: data.request_id,
      requestId: data.request_id,
      model: MODEL,
      status: data.status || "IN_QUEUE",
      queuePosition: data.queue_position ?? null,
      message: "Scene queued successfully.",
      creditSource: credit.source,
      creditsRemaining: credit.remaining,
    });
  } catch (error) {
    return NextResponse.json({
      error: error instanceof Error ? error.message : "Could not start generation. Check your server configuration and try again.",
    }, { status: 500 });
  }
}
