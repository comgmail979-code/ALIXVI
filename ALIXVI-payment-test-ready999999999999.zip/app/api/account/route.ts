import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

export async function GET() {
  try {
    const supabase = createSupabaseServerClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({
        authenticated: false,
        trialVideosRemaining: 0,
        paidVideoCredits: 0,
        monthlyVideoCredits: 0,
      });
    }

    const [profileResult, subscriptionResult, paymentsResult] = await Promise.all([
      supabase
        .from("alixvi_profiles")
        .select("free_videos_used, display_name")
        .eq("user_id", user.id)
        .single(),
      supabase
        .from("alixvi_subscriptions")
        .select("status, current_period_end, current_period_start, amount_rwf, provider")
        .eq("user_id", user.id)
        .in("status", ["active", "cancelled", "past_due", "expired"])
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabase
        .from("alixvi_payments")
        .select("checkout_reference, amount_rwf, provider, status, created_at, paid_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(5),
    ]);

    if (profileResult.error) throw profileResult.error;
    if (subscriptionResult.error) throw subscriptionResult.error;
    if (paymentsResult.error) throw paymentsResult.error;

    const profile = profileResult.data;
    const subscription = subscriptionResult.data;
    const trialVideosRemaining = Math.max(0, 2 - (profile?.free_videos_used ?? 0));

    return NextResponse.json({
      authenticated: true,
      email: user.email,
      displayName: profile?.display_name ?? null,
      trialVideosRemaining,
      // Paid credits are not yet part of the current live schema. Do not invent a balance.
      paidVideoCredits: 0,
      monthlyVideoCredits: 0,
      subscriptionStatus: subscription?.status ?? "free",
      subscriptionRenewsAt: subscription?.current_period_end ?? null,
      payments: (paymentsResult.data ?? []).map((payment) => ({
        tx_ref: payment.checkout_reference ?? payment.paid_at ?? payment.created_at,
        amount_rwf: payment.amount_rwf,
        payment_method: payment.provider,
        status: payment.status,
        created_at: payment.created_at,
      })),
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not load account." },
      { status: 503 },
    );
  }
}
