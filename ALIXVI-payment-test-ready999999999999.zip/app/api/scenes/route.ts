import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

// Return only completed renders owned by the signed-in user. RLS is also
// enforced by Supabase; no service-role key is used for this read.
export async function GET() {
  try {
    const supabase = createSupabaseServerClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: "Sign in to import your completed scenes." }, { status: 401 });
    }

    const { data, error } = await supabase
      .from("generation_jobs")
      .select("id, scene_number, model, status, video_url, created_at")
      .eq("user_id", user.id)
      .eq("status", "COMPLETED")
      .not("video_url", "is", null)
      .order("created_at", { ascending: true })
      .limit(50);

    if (error) {
      return NextResponse.json({ error: "Could not load completed scenes. Check that the ALIXVI database migration is installed." }, { status: 503 });
    }

    return NextResponse.json({ scenes: data ?? [] });
  } catch (error) {
    return NextResponse.json({
      error: error instanceof Error ? error.message : "Could not load completed scenes.",
    }, { status: 503 });
  }
}
