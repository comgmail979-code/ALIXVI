import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";
const MODEL = "minimax/h3-max/text-to-video";

export async function GET(_request: Request, context: { params: { id: string } }) {
  const key = process.env.FAL_KEY;
  const requestId = context.params.id;
  if (!key) return NextResponse.json({ status: "SETUP", message: "FAL_KEY is not configured." }, { status: 503 });
  if (!/^[a-zA-Z0-9-]+$/.test(requestId)) {
    return NextResponse.json({ status: "FAILED", message: "Invalid request identifier." }, { status: 400 });
  }

  try {
    const supabase = createSupabaseServerClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) return NextResponse.json({ status: "FAILED", message: "Please sign in to view your render." }, { status: 401 });
    const { data: job, error: jobError } = await supabase.from("generation_jobs")
      .select("id, provider_request_id, user_id")
      .eq("provider_request_id", requestId).eq("user_id", user.id).single();
    if (jobError || !job) return NextResponse.json({ status: "FAILED", message: "Render not found for this account." }, { status: 404 });

    const admin = createSupabaseAdminClient();
    const base = `https://queue.fal.run/${MODEL}/requests/${requestId}`;
    const statusRes = await fetch(`${base}/status`, {
      headers: { Authorization: `Key ${key}` }, cache: "no-store",
    });
    const statusData = await statusRes.json().catch(() => ({}));
    if (!statusRes.ok) {
      return NextResponse.json({ status: "FAILED", message: statusData.detail || "Could not retrieve scene status." }, { status: 502 });
    }
    if (statusData.status !== "COMPLETED") {
      if (statusData.status === "FAILED") {
        await admin.rpc("refund_failed_generation", { p_job_id: job.id });
      }
      return NextResponse.json({
        status: statusData.status || "IN_PROGRESS",
        queuePosition: statusData.queue_position ?? null,
        message: statusData.status === "IN_QUEUE" ? "Waiting in the video provider queue…" : statusData.status === "FAILED" ? "The video provider could not render this scene." : "Rendering this scene…",
      });
    }
    if (statusData.error || statusData.error_type) {
      await admin.rpc("refund_failed_generation", { p_job_id: job.id });
      return NextResponse.json({ status: "FAILED", message: statusData.error || statusData.error_type || "The provider could not render this scene." });
    }

    const resultRes = await fetch(base, { headers: { Authorization: `Key ${key}` }, cache: "no-store" });
    const result = await resultRes.json().catch(() => ({}));
    if (!resultRes.ok) {
      await admin.rpc("refund_failed_generation", { p_job_id: job.id });
      return NextResponse.json({ status: "FAILED", message: result.detail || "The provider could not return the finished scene." }, { status: 502 });
    }
    const videoUrl = result.video?.url || result.output?.video?.url || result.video_url || null;
    if (!videoUrl) await admin.rpc("refund_failed_generation", { p_job_id: job.id });
    else await admin.from("generation_jobs").update({ status: "COMPLETED", video_url: videoUrl, updated_at: new Date().toISOString() }).eq("id", job.id);
    return NextResponse.json({
      status: videoUrl ? "COMPLETED" : "FAILED",
      videoUrl,
      message: videoUrl ? "Scene rendered successfully." : "The provider completed, but no video URL was returned.",
    });
  } catch (error) {
    return NextResponse.json({ status: "FAILED", message: error instanceof Error ? error.message : "Could not contact the video provider." }, { status: 503 });
  }
}
