import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

type MovieScene = { id: string; title: string; url: string; duration: string; sourceJobId?: string };

async function getUserClient() {
  const supabase = createSupabaseServerClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return { supabase, user: null };
  return { supabase, user };
}

export async function GET() {
  try {
    const { supabase, user } = await getUserClient();
    if (!user) return NextResponse.json({ error: "Sign in to access your Movie Library." }, { status: 401 });
    const { data, error } = await supabase.from("movie_projects")
      .select("id, title, scenes, created_at, updated_at")
      .eq("user_id", user.id).order("updated_at", { ascending: false }).limit(50);
    if (error) throw error;
    return NextResponse.json({ movies: data ?? [] });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not load Movie Library." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  try {
    const { supabase, user } = await getUserClient();
    if (!user) return NextResponse.json({ error: "Sign in to save movies." }, { status: 401 });
    const body = await request.json();
    const title = typeof body.title === "string" ? body.title.trim().slice(0, 100) : "";
    const scenes = body.scenes as MovieScene[];
    if (!title) return NextResponse.json({ error: "Enter a movie title." }, { status: 400 });
    if (!Array.isArray(scenes) || scenes.length < 2 || scenes.length > 20) {
      return NextResponse.json({ error: "A saved movie must contain between 2 and 20 scenes." }, { status: 400 });
    }
    const safeScenes = scenes.map((scene) => {
      if (!scene || typeof scene.url !== "string" || !/^https:\/\//i.test(scene.url) || scene.url.length > 2048) {
        throw new Error("Every scene must have a valid HTTPS video URL.");
      }
      return {
        id: String(scene.id || "").slice(0, 100),
        title: String(scene.title || "Scene").slice(0, 100),
        url: scene.url,
        duration: String(scene.duration || "8").slice(0, 8),
        ...(scene.sourceJobId ? { sourceJobId: String(scene.sourceJobId).slice(0, 100) } : {}),
      };
    });
    const { data, error } = await supabase.from("movie_projects").insert({
      user_id: user.id, title, scenes: safeScenes,
    }).select("id, title, scenes, created_at, updated_at").single();
    if (error) throw error;
    return NextResponse.json({ movie: data }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not save this movie." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { supabase, user } = await getUserClient();
    if (!user) return NextResponse.json({ error: "Sign in to delete saved movies." }, { status: 401 });
    const id = new URL(request.url).searchParams.get("id");
    if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "Invalid movie ID." }, { status: 400 });
    const { error } = await supabase.from("movie_projects").delete().eq("id", id).eq("user_id", user.id);
    if (error) throw error;
    return NextResponse.json({ deleted: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not delete this movie." }, { status: 503 });
  }
}
