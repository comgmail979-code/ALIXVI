"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Clapperboard, CreditCard, LoaderCircle, LogOut, Smartphone, Sparkles } from "lucide-react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

type Payment = { tx_ref: string; amount_rwf: number; payment_method: string; status: string; created_at: string };
type AccountData = {
  authenticated: boolean;
  email?: string;
  trialVideosRemaining: number;
  paidVideoCredits: number;
  monthlyVideoCredits: number;
  subscriptionStatus?: string;
  subscriptionRenewsAt?: string | null;
  payments?: Payment[];
};

export default function AccountPage() {
  const [account, setAccount] = useState<AccountData | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function loadAccount() {
    const response = await fetch("/api/account", { cache: "no-store" });
    const data = await response.json();
    if (!data.authenticated) router.replace("/login");
    else setAccount(data);
  }

  useEffect(() => {
    loadAccount().catch(() => setMessage("Could not load your account. Please refresh."));
    const paymentState = new URLSearchParams(window.location.search).get("payment");
    if (paymentState === "success") setMessage("Payment verified. Your monthly membership has been activated.");
    if (paymentState === "pending") setMessage("Your payment is being confirmed. Refresh this page in a moment.");
    if (paymentState === "not-completed") setMessage("Payment was not completed. You can try again when ready.");
  }, [router]);

  async function startCheckout(method: "card" | "mobilemoneyrwanda") {
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/payments/checkout", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ method }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Could not start payment.");
      window.location.assign(data.checkoutUrl);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not start payment.");
      setBusy(false);
    }
  }

  async function signOut() {
    setBusy(true);
    try {
      const supabase = createSupabaseBrowserClient();
      await supabase.auth.signOut();
      router.replace("/"); router.refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not sign out.");
    } finally { setBusy(false); }
  }

  return <main className="auth-page"><nav className="nav wrap"><Link className="brand" href="/"><span className="brand-mark"><Clapperboard size={20}/></span> ALIXVI<span className="brand-dot">.</span></Link><Link className="text-link" href="/#studio">Back to studio ↗</Link></nav><section className="auth-card account-card"><div className="eyebrow">CREATOR DASHBOARD</div><h1>Your account.</h1>{!account ? <p className="auth-sub"><LoaderCircle className="spin" size={16}/> Loading account…</p> : <>
    <p className="auth-sub">{account.email}</p>
    <div className="account-balance"><div><span>FREE TRIAL VIDEOS</span><strong>{account.trialVideosRemaining}</strong></div><div><span>MONTHLY MEMBERSHIP</span><strong>{account.subscriptionStatus === "active" || (account.subscriptionStatus === "cancelled" && !!account.subscriptionRenewsAt && new Date(account.subscriptionRenewsAt) > new Date()) ? "Active" : "Free"}</strong></div></div>
    <div className="account-plan"><span className="price-kicker">CURRENT PLAN</span><strong>{account.subscriptionStatus === "active" ? "Creator Monthly" : account.subscriptionStatus === "cancelled" && account.subscriptionRenewsAt && new Date(account.subscriptionRenewsAt) > new Date() ? "Creator Monthly · cancelled" : "Free beginner"}</strong><p>{account.subscriptionStatus === "active" ? "Unlimited video generations while your monthly membership is active." : account.subscriptionStatus === "cancelled" && account.subscriptionRenewsAt && new Date(account.subscriptionRenewsAt) > new Date() ? "Your membership will not renew. Access remains active until the paid-through date." : "You have two free video generations to try ALIXVI."}</p>{account.subscriptionRenewsAt && <small>Paid-through / renewal date: {new Date(account.subscriptionRenewsAt).toLocaleDateString()}</small>}</div>
    {(account.subscriptionStatus !== "active" && !(account.subscriptionStatus === "cancelled" && account.subscriptionRenewsAt && new Date(account.subscriptionRenewsAt) > new Date())) && <div className="billing-box"><div className="eyebrow">CREATOR MONTHLY · 3,000 RWF / MONTH</div><h2>Choose how to pay</h2><p className="auth-sub">Secure checkout hosted by Flutterwave. Your account is activated only after the payment is verified.</p><button className="price-button billing-action" onClick={() => startCheckout("mobilemoneyrwanda")} disabled={busy}><Smartphone size={17}/>{busy ? "Opening checkout…" : "MTN MoMo / Airtel Money"}</button><button className="price-button secondary-price billing-action" onClick={() => startCheckout("card")} disabled={busy}><CreditCard size={17}/>{busy ? "Opening checkout…" : "Visa / Mastercard"}</button><small className="price-disclaimer">Mobile Money renews manually each month. Renewal is manual: pay again each month to continue your membership.</small></div>}
    {account.payments && account.payments.length > 0 && <div className="payment-history"><h3>Recent payments</h3>{account.payments.map(payment => <div className="payment-row" key={payment.tx_ref}><span>{"Flutterwave"}<small>{new Date(payment.created_at).toLocaleDateString()}</small></span><strong>{payment.amount_rwf.toLocaleString()} RWF</strong><em className={`payment-status ${payment.status}`}>{payment.status}</em></div>)}</div>}
    <Link className="text-link account-studio-link" href="/#studio">Open video studio <Sparkles size={14}/></Link>
  </>}<button className="signout-button" onClick={signOut} disabled={busy}><LogOut size={15}/>{busy ? "Please wait…" : "Sign out"}</button>{message && <p className="auth-message">{message}</p>}</section></main>;
}
