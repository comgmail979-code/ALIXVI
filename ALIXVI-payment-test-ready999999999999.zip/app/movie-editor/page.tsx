"use client";
import { useMemo, useState } from "react";
import Link from "next/link";

type Scene = { id: string; title: string; url: string; duration: string; sourceJobId?: string };
type CompletedScene = { id: string; scene_number: number; model: string; video_url: string; created_at: string };
type SavedMovie = { id: string; title: string; scenes: Scene[]; created_at: string; updated_at: string };

export default function MovieEditorPage() {
  const [scenes, setScenes] = useState<Scene[]>([
    { id: "scene-1", title: "Scene 1", url: "", duration: "8" },
    { id: "scene-2", title: "Scene 2", url: "", duration: "8" },
  ]);
  const [title, setTitle] = useState("My ALIXVI Movie");
  const [busy, setBusy] = useState(false);
  const [loadingScenes, setLoadingScenes] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [readyUrl, setReadyUrl] = useState("");
  const [availableScenes, setAvailableScenes] = useState<CompletedScene[]>([]);
  const [selectedJobs, setSelectedJobs] = useState<string[]>([]);
  const [savedMovies, setSavedMovies] = useState<SavedMovie[]>([]);
  const [libraryBusy, setLibraryBusy] = useState(false);

  const totalSeconds = useMemo(() => scenes.reduce((n, s) => n + (Number(s.duration) || 0), 0), [scenes]);
  function update(id: string, patch: Partial<Scene>) {
    setScenes(old => old.map(s => s.id === id ? { ...s, ...patch } : s));
    setReadyUrl("");
  }
  function move(i: number, d: -1 | 1) {
    const j = i + d;
    if (j < 0 || j >= scenes.length) return;
    setScenes(old => { const a = [...old]; [a[i], a[j]] = [a[j], a[i]]; return a; });
    setReadyUrl("");
  }
  async function loadCompletedScenes() {
    setLoadingScenes(true); setError(""); setNotice("");
    try {
      const response = await fetch("/api/scenes", { cache: "no-store" });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "Could not load completed scenes.");
      setAvailableScenes(data.scenes || []);
      setSelectedJobs((data.scenes || []).map((s: CompletedScene) => s.id));
      if (!(data.scenes || []).length) setNotice("No completed scenes yet. Generate scenes and check their status, then refresh this list.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load completed scenes.");
    } finally { setLoadingScenes(false); }
  }
  function importSelectedScenes() {
    const chosen = availableScenes.filter(s => selectedJobs.includes(s.id));
    if (!chosen.length) { setError("Select at least one completed scene to import."); return; }
    const existing = new Set(scenes.map(s => s.sourceJobId).filter(Boolean));
    const fresh = chosen.filter(s => !existing.has(s.id));
    if (!fresh.length) { setNotice("Those scenes are already in your movie timeline."); return; }
    const additions: Scene[] = fresh.map((s, i) => ({
      id: `job-${s.id}`,
      sourceJobId: s.id,
      title: `Scene ${s.scene_number || scenes.length + i + 1}`,
      url: s.video_url,
      duration: "8",
    }));
    setScenes(old => [...old, ...additions].slice(0, 20));
    setReadyUrl(""); setError("");
    setNotice(`${Math.min(fresh.length, Math.max(0, 20 - scenes.length))} completed scene(s) added to your timeline.`);
  }
  async function loadMovieLibrary() {
    setLibraryBusy(true); setError("");
    try {
      const r = await fetch("/api/movies", { cache: "no-store" });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || "Could not load Movie Library.");
      setSavedMovies(d.movies || []);
      if (!(d.movies || []).length) setNotice("Your Movie Library is empty. Save a timeline to keep working on it later.");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not load Movie Library."); }
    finally { setLibraryBusy(false); }
  }
  async function saveMovie() {
    setLibraryBusy(true); setError(""); setNotice("");
    try {
      const r = await fetch("/api/movies", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title, scenes }) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || "Could not save movie.");
      setSavedMovies(old => [d.movie, ...old.filter(m => m.id !== d.movie.id)].slice(0, 50));
      setNotice("Movie timeline saved to your ALIXVI Library.");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not save movie."); }
    finally { setLibraryBusy(false); }
  }
  function openSavedMovie(movie: SavedMovie) {
    setTitle(movie.title); setScenes(movie.scenes); setReadyUrl(""); setNotice(`Loaded “${movie.title}” from your library.`); setError("");
  }
  async function deleteSavedMovie(id: string) {
    if (!window.confirm("Delete this saved movie timeline?")) return;
    setLibraryBusy(true); setError("");
    try {
      const r = await fetch(`/api/movies?id=${encodeURIComponent(id)}`, { method: "DELETE" });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || "Could not delete movie.");
      setSavedMovies(old => old.filter(m => m.id !== id)); setNotice("Saved movie deleted.");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not delete movie."); }
    finally { setLibraryBusy(false); }
  }
  async function exportMovie() {
    setBusy(true); setError(""); setReadyUrl("");
    try {
      if (scenes.length < 2 || scenes.length > 20) throw new Error("Use between 2 and 20 scenes.");
      if (scenes.some(s => !s.url.trim())) throw new Error("Every scene needs a completed video URL. Import completed scenes or paste a URL.");
      const r = await fetch("/api/export", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title, scenes: scenes.map(s => ({ url: s.url.trim() })) }) });
      if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || "Movie export failed."); }
      const blob = await r.blob(); setReadyUrl(URL.createObjectURL(blob));
    } catch (e) { setError(e instanceof Error ? e.message : "Could not export movie."); }
    finally { setBusy(false); }
  }

  return <main className="min-h-screen px-5 py-10"><div className="mx-auto max-w-4xl">
    <Link href="/" className="text-sm opacity-70">← Back to ALIXVI</Link>
    <header className="mt-6 flex flex-wrap items-end justify-between gap-4"><div><p className="text-sm uppercase tracking-[.25em] opacity-60">ALIXVI Studio</p><h1 className="mt-2 text-4xl font-semibold">Movie editor</h1><p className="mt-2 opacity-70">Import your AI renders, arrange scenes and combine them into one MP4 movie.</p></div><div className="rounded-xl border border-white/10 px-4 py-3"><div className="text-xs opacity-60">Estimated runtime</div><div className="text-xl font-semibold">{Math.floor(totalSeconds / 60)}m {totalSeconds % 60}s</div></div></header>

    <section className="mt-8 rounded-2xl border border-white/10 bg-white/[.03] p-5"><h2 className="text-lg font-semibold">Import your completed AI scenes</h2><p className="mt-1 text-sm opacity-65">Load finished renders from your ALIXVI account. Select the scenes you want, then add them to the timeline.</p><div className="mt-4 flex flex-wrap gap-3"><button onClick={loadCompletedScenes} disabled={loadingScenes} className="rounded-xl border border-white/20 px-4 py-3 disabled:opacity-50">{loadingScenes ? "Loading scenes…" : "↻ Load my completed scenes"}</button>{availableScenes.length > 0 && <button onClick={importSelectedScenes} disabled={selectedJobs.length === 0 || scenes.length >= 20} className="rounded-xl bg-white px-4 py-3 font-semibold text-black disabled:opacity-40">Import selected ({selectedJobs.length})</button>}</div>
      {availableScenes.length > 0 && <div className="mt-4 space-y-2">{availableScenes.map((s, i) => <label key={s.id} className="flex cursor-pointer items-center gap-3 rounded-lg border border-white/10 p-3"><input type="checkbox" checked={selectedJobs.includes(s.id)} disabled={scenes.length >= 20 && !scenes.some(x => x.sourceJobId === s.id)} onChange={e => setSelectedJobs(old => e.target.checked ? [...old, s.id] : old.filter(id => id !== s.id))} /><span className="min-w-0 flex-1"><span className="block font-medium">Completed render {s.scene_number || i + 1}</span><span className="block truncate text-xs opacity-55">{s.model} · {new Date(s.created_at).toLocaleString()}</span></span><span className="text-xs text-green-300">Ready</span></label>)}</div>}
    </section>

    <section className="mt-6 rounded-2xl border border-white/10 bg-white/[.03] p-5"><div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-lg font-semibold">My Movie Library</h2><div className="flex gap-2"><button onClick={loadMovieLibrary} disabled={libraryBusy} className="rounded-lg border border-white/20 px-3 py-2 text-sm disabled:opacity-50">{libraryBusy ? "Please wait…" : "Load library"}</button><button onClick={saveMovie} disabled={libraryBusy || scenes.length < 2 || scenes.some(s => !s.url.trim())} className="rounded-lg bg-white px-3 py-2 text-sm font-semibold text-black disabled:opacity-40">Save timeline</button></div></div><p className="mt-1 text-xs opacity-60">Save your scene order and video links, then reopen the project later from your account.</p>{savedMovies.length > 0 && <div className="mt-4 space-y-2">{savedMovies.map(movie => <div key={movie.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-white/10 p-3"><div className="min-w-0 flex-1"><p className="truncate font-medium">{movie.title}</p><p className="text-xs opacity-55">{movie.scenes.length} scenes · {new Date(movie.updated_at).toLocaleDateString()}</p></div><button onClick={() => openSavedMovie(movie)} className="rounded-lg border border-white/20 px-3 py-2 text-sm">Open</button><button onClick={() => deleteSavedMovie(movie.id)} disabled={libraryBusy} className="rounded-lg border border-red-400/30 px-3 py-2 text-sm text-red-300 disabled:opacity-40">Delete</button></div>)}</div>}</section>
    <section className="mt-6 rounded-2xl border border-white/10 bg-white/[.03] p-5"><label className="mb-2 block text-sm opacity-70">Movie title</label><input value={title} onChange={e => setTitle(e.target.value)} className="w-full rounded-lg border border-white/15 bg-black/20 px-3 py-3" /></section>
    <div className="mt-6 space-y-4">{scenes.map((s, i) => <section key={s.id} className="rounded-2xl border border-white/10 bg-white/[.03] p-5"><div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-semibold">{i + 1}. {s.title}</h2><p className="text-xs opacity-60">{s.sourceJobId ? "Imported from your completed ALIXVI renders" : "Paste a completed video URL"}</p></div><div className="flex gap-2"><button onClick={() => move(i, -1)} disabled={!i} className="rounded-lg border border-white/15 px-3 py-2 disabled:opacity-30">↑</button><button onClick={() => move(i, 1)} disabled={i === scenes.length - 1} className="rounded-lg border border-white/15 px-3 py-2 disabled:opacity-30">↓</button><button onClick={() => setScenes(old => old.filter(x => x.id !== s.id))} disabled={scenes.length <= 2} className="rounded-lg border border-red-400/30 px-3 py-2 text-red-300 disabled:opacity-30">Remove</button></div></div><input value={s.url} onChange={e => update(s.id, { url: e.target.value })} placeholder="https://.../completed-scene.mp4" className="w-full rounded-lg border border-white/15 bg-black/20 px-3 py-3" /><p className="mt-2 text-xs opacity-50">Scene duration estimate: {s.duration} seconds (export uses the source clip's actual duration).</p></section>)}</div>
    <button onClick={() => setScenes(old => [...old, { id: `scene-${Date.now()}`, title: `Scene ${old.length + 1}`, url: "", duration: "8" }])} disabled={scenes.length >= 20} className="mt-4 rounded-xl border border-dashed border-white/25 px-5 py-3 disabled:opacity-30">+ Add another scene</button>
    <section className="mt-6 rounded-2xl border border-white/10 bg-white/[.03] p-5"><h2 className="text-lg font-semibold">Export your movie</h2><p className="mt-1 text-sm opacity-65">ALIXVI normalizes the clips and joins them in the order above. Two to twenty finished clips are supported.</p>{error && <p role="alert" className="mt-4 rounded-lg bg-red-500/10 p-3 text-sm text-red-300">{error}</p>}{notice && <p className="mt-4 rounded-lg bg-white/5 p-3 text-sm opacity-80">{notice}</p>}<button onClick={exportMovie} disabled={busy} className="mt-5 w-full rounded-xl bg-white px-5 py-3 font-semibold text-black disabled:opacity-50">{busy ? "Combining scenes…" : "Export final MP4"}</button>{readyUrl && <div className="mt-5 space-y-3"><video src={readyUrl} controls className="w-full rounded-xl bg-black" /><a href={readyUrl} download={`${title.trim().replace(/[^a-z0-9-_]+/gi, "-") || "alixvi-movie"}.mp4`} className="inline-flex rounded-xl border border-white/20 px-5 py-3">Download final movie</a></div>}</section>
  </div></main>;
}
