import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const FLW_API = "https://api.flutterwave.com/v3";

type FlutterwaveVerifyResponse = {
  status?: string;
  data?: {
    id?: number | string;
    tx_ref?: string;
    status?: string;
    amount?: number;
    currency?: string;
    customer?: { email?: string };
  };
};

export async function verifyAndApplyFlutterwavePayment(transactionId: string, expectedTxRef?: string) {
  const secret = process.env.FLW_SECRET_KEY;
  if (!secret) throw new Error("Flutterwave is not configured.");
  if (!expectedTxRef && !/^\d+$/.test(transactionId)) throw new Error("Invalid Flutterwave transaction ID.");

  // Prefer the merchant reference endpoint so callback and webhook verification
  // both bind the payment to the unique ALIXVI checkout reference.
  const verifyUrl = expectedTxRef
    ? `${FLW_API}/transactions/verify_by_reference?tx_ref=${encodeURIComponent(expectedTxRef)}`
    : `${FLW_API}/transactions/${encodeURIComponent(transactionId)}/verify`;
  const response = await fetch(verifyUrl, {
    headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
    cache: "no-store",
  });
  const result = await response.json() as FlutterwaveVerifyResponse;
  if (!response.ok || result.status !== "success" || !result.data) {
    throw new Error("Flutterwave could not verify this transaction.");
  }

  const payment = result.data;
  if (payment.status !== "successful" || !payment.id || !payment.tx_ref ||
      String(payment.id) !== String(transactionId) ||
      (expectedTxRef && payment.tx_ref !== expectedTxRef) ||
      payment.currency !== "RWF" || typeof payment.amount !== "number" || payment.amount !== 3000) {
    throw new Error("The payment is not successful or its amount/reference/currency does not match ALIXVI.");
  }

  const admin = createSupabaseAdminClient();
  const { data, error } = await admin.rpc("apply_verified_flutterwave_payment", {
    p_tx_ref: payment.tx_ref,
    p_transaction_id: String(payment.id),
    p_amount: payment.amount,
    p_currency: payment.currency,
    p_customer_email: payment.customer?.email ?? null,
  });
  if (error) throw new Error(`Could not activate the ALIXVI membership: ${error.message}`);
  return data as { applied: boolean; reason?: string; subscription_id?: string; current_period_end?: string };
}
