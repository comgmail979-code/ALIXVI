-- ALIXVI billing integration against the current alixvi_* schema.
-- A payment only grants membership after a server-side Flutterwave verification.

create unique index if not exists alixvi_payments_provider_transaction_id_uidx
  on public.alixvi_payments(provider_transaction_id)
  where provider_transaction_id is not null;

create or replace function public.apply_verified_flutterwave_payment(
  p_tx_ref text,
  p_transaction_id text,
  p_amount numeric,
  p_currency text,
  p_customer_email text default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  payment_row public.alixvi_payments%rowtype;
  subscription_row public.alixvi_subscriptions%rowtype;
  next_period_start timestamptz;
  next_period_end timestamptz;
begin
  if coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role' then
    raise exception 'service role required';
  end if;
  if coalesce(p_tx_ref, '') = '' or coalesce(p_transaction_id, '') = ''
     or p_currency <> 'RWF' or p_amount <> 3000 then
    raise exception 'invalid verified payment details';
  end if;

  -- Idempotent webhook/callback handling: a Flutterwave transaction can arrive twice.
  if exists (
    select 1 from public.alixvi_payments
    where provider_transaction_id = p_transaction_id
  ) then
    return jsonb_build_object('applied', false, 'reason', 'already_applied');
  end if;

  select * into payment_row
  from public.alixvi_payments
  where checkout_reference = p_tx_ref
  for update;

  if not found then
    raise exception 'payment reference does not belong to a pending ALIXVI checkout';
  end if;
  if payment_row.status <> 'pending' then
    raise exception 'payment reference is not pending';
  end if;
  if payment_row.amount_rwf <> 3000 or payment_row.currency <> p_currency then
    raise exception 'payment amount or currency does not match checkout';
  end if;

  update public.alixvi_payments
    set status = 'successful', provider_transaction_id = p_transaction_id, paid_at = now()
    where id = payment_row.id;

  select * into subscription_row
  from public.alixvi_subscriptions
  where user_id = payment_row.user_id
  order by created_at desc
  limit 1
  for update;

  if found then
    next_period_start := greatest(now(), coalesce(subscription_row.current_period_end, now()));
    next_period_end := next_period_start + interval '1 month';
    update public.alixvi_subscriptions
      set plan = 'monthly', amount_rwf = 3000, status = 'active', provider = 'flutterwave',
          current_period_start = next_period_start, current_period_end = next_period_end,
          cancel_at_period_end = false, updated_at = now()
      where id = subscription_row.id;
  else
    next_period_start := now();
    next_period_end := next_period_start + interval '1 month';
    insert into public.alixvi_subscriptions (
      user_id, plan, amount_rwf, status, provider,
      current_period_start, current_period_end, cancel_at_period_end
    ) values (
      payment_row.user_id, 'monthly', 3000, 'active', 'flutterwave',
      next_period_start, next_period_end, false
    ) returning * into subscription_row;
  end if;

  update public.alixvi_payments
    set subscription_id = subscription_row.id
    where id = payment_row.id;

  return jsonb_build_object(
    'applied', true,
    'subscription_id', subscription_row.id,
    'current_period_start', next_period_start,
    'current_period_end', next_period_end
  );
end;
$$;

revoke all on function public.apply_verified_flutterwave_payment(text, text, numeric, text, text)
  from public, anon, authenticated;
grant execute on function public.apply_verified_flutterwave_payment(text, text, numeric, text, text)
  to service_role;

create or replace function public.set_flutterwave_subscription_state(
  p_customer_email text,
  p_state text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_user_id uuid;
begin
  if coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role' then
    raise exception 'service role required';
  end if;
  if p_state not in ('past_due', 'cancelled') then
    raise exception 'invalid subscription state';
  end if;

  select id into target_user_id
  from auth.users
  where lower(email) = lower(p_customer_email)
  limit 1;
  if target_user_id is null then return; end if;

  update public.alixvi_subscriptions
    set status = p_state,
        cancel_at_period_end = (p_state = 'cancelled'),
        updated_at = now()
    where user_id = target_user_id
      and status in ('active', 'past_due')
      and current_period_end > now();
end;
$$;

revoke all on function public.set_flutterwave_subscription_state(text, text)
  from public, anon, authenticated;
grant execute on function public.set_flutterwave_subscription_state(text, text)
  to service_role;
