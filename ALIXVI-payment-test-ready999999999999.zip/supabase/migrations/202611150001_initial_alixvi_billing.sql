-- Run this migration in the Supabase SQL editor before enabling public accounts.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  trial_videos_remaining integer not null default 2 check (trial_videos_remaining >= 0),
  paid_video_credits integer not null default 0 check (paid_video_credits >= 0),
  subscription_status text not null default 'free' check (subscription_status in ('free','active','past_due','cancelled')),
  subscription_renews_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.generation_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider_request_id text not null unique,
  model text not null,
  scene_number integer not null default 1,
  credit_source text not null check (credit_source in ('trial','paid')),
  credit_refunded boolean not null default false,
  status text not null default 'IN_QUEUE',
  video_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists generation_jobs_user_created_idx on public.generation_jobs(user_id, created_at desc);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.generation_jobs enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile" on public.profiles for select using (auth.uid() = id);
drop policy if exists "Users can read own generation jobs" on public.generation_jobs;
create policy "Users can read own generation jobs" on public.generation_jobs for select using (auth.uid() = user_id);
drop policy if exists "Users can create own generation jobs" on public.generation_jobs;
drop policy if exists "Users can update own generation jobs" on public.generation_jobs;
-- Job writes are server-only via the Supabase service-role key. End users can only read their own jobs.

create or replace function public.consume_video_credit()
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.profiles%rowtype;
begin
  if auth.uid() is null then return jsonb_build_object('allowed', false, 'reason', 'sign_in_required'); end if;
  select * into p from public.profiles where id = auth.uid() for update;
  if not found then return jsonb_build_object('allowed', false, 'reason', 'profile_missing'); end if;
  if p.trial_videos_remaining > 0 then
    update public.profiles set trial_videos_remaining = trial_videos_remaining - 1, updated_at = now() where id = auth.uid();
    return jsonb_build_object('allowed', true, 'source', 'trial', 'remaining', p.trial_videos_remaining - 1);
  end if;
  if p.subscription_status = 'active' and p.paid_video_credits > 0 then
    update public.profiles set paid_video_credits = paid_video_credits - 1, updated_at = now() where id = auth.uid();
    return jsonb_build_object('allowed', true, 'source', 'paid', 'remaining', p.paid_video_credits - 1);
  end if;
  return jsonb_build_object('allowed', false, 'reason', 'credits_required');
end;
$$;

create or replace function public.refund_video_credit(p_user_id uuid, p_source text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.role() <> 'service_role' then raise exception 'service role required'; end if;
  if p_source = 'trial' then
    update public.profiles set trial_videos_remaining = trial_videos_remaining + 1, updated_at = now() where id = p_user_id;
  elsif p_source = 'paid' then
    update public.profiles set paid_video_credits = paid_video_credits + 1, updated_at = now() where id = p_user_id;
  else
    raise exception 'invalid credit source';
  end if;
end;
$$;

revoke all on function public.consume_video_credit() from public;
grant execute on function public.consume_video_credit() to authenticated;
revoke all on function public.refund_video_credit(uuid, text) from public;
grant execute on function public.refund_video_credit(uuid, text) to service_role;


create or replace function public.refund_failed_generation(p_job_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare j public.generation_jobs%rowtype;
begin
  if auth.role() <> 'service_role' then raise exception 'service role required'; end if;
  select * into j from public.generation_jobs where id = p_job_id for update;
  if not found or j.credit_refunded or j.status = 'COMPLETED' then return; end if;
  if j.credit_source = 'trial' then
    update public.profiles set trial_videos_remaining = trial_videos_remaining + 1, updated_at = now() where id = j.user_id;
  else
    update public.profiles set paid_video_credits = paid_video_credits + 1, updated_at = now() where id = j.user_id;
  end if;
  update public.generation_jobs set credit_refunded = true, status = 'FAILED', updated_at = now() where id = p_job_id;
end;
$$;
revoke all on function public.refund_failed_generation(uuid) from public;
grant execute on function public.refund_failed_generation(uuid) to service_role;
