-- Flutterwave checkout ledger and verified-payment activation.
-- Run after 202611150001_initial_alixvi_billing.sql.

alter table public.profiles
  add column if not exists monthly_video_credits integer not null default 0 check (monthly_video_credits >= 0);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tx_ref text not null unique,
  provider_transaction_id text unique,
  provider text not null default 'flutterwave',
  payment_method text not null check (payment_method in ('card','mobilemoneyrwanda')),
  amount_rwf integer not null check (amount_rwf > 0),
  currency text not null default 'RWF' check (currency = 'RWF'),
  credits_granted integer not null check (credits_granted > 0),
  status text not null default 'pending' check (status in ('pending','successful','failed')),
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create index if not exists payments_user_created_idx on public.payments(user_id, created_at desc);
alter table public.payments enable row level security;
drop policy if exists "Users can read own payments" on public.payments;
create policy "Users can read own payments" on public.payments for select using (auth.uid() = user_id);

-- This RPC is only callable by the service role after server-side Flutterwave verification.
-- It is idempotent by provider transaction ID, including recurring card charges.
create or replace function public.apply_verified_flutterwave_payment(
  p_tx_ref text,
  p_transaction_id text,
  p_amount numeric,
  p_currency text,
  p_customer_email text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  payment_row public.payments%rowtype;
  target_user_id uuid;
  credit_count integer;
  expected_amount integer;
  inserted_id uuid;
begin
  if auth.role() <> 'service_role' then raise exception 'service role required'; end if;
  if p_transaction_id is null or p_transaction_id = '' or p_currency <> 'RWF' then
    raise exception 'invalid verified payment details';
  end if;

  -- First payment: match the exact pending checkout created by ALIXVI.
  select * into payment_row from public.payments where tx_ref = p_tx_ref for update;
  if found and payment_row.status = 'pending' then
    if payment_row.amount_rwf <> round(p_amount)::integer or payment_row.currency <> p_currency then
      raise exception 'payment does not match pending checkout';
    end if;

    update public.payments
      set status = 'successful', provider_transaction_id = p_transaction_id, paid_at = now()
      where id = payment_row.id;
    update public.profiles
      set subscription_status = 'active',
          paid_video_credits = paid_video_credits + payment_row.credits_granted,
          monthly_video_credits = payment_row.credits_granted,
          subscription_renews_at = now() + interval '1 month',
          updated_at = now()
      where id = payment_row.user_id;
    return jsonb_build_object('applied', true, 'user_id', payment_row.user_id, 'credits', payment_row.credits_granted);
  elsif found and payment_row.status = 'successful' and payment_row.provider_transaction_id = p_transaction_id then
    return jsonb_build_object('applied', false, 'reason', 'already_applied');
  elsif found and payment_row.status <> 'successful' then
    raise exception 'payment reference is not pending';
  end if;

  -- Subsequent automatic card renewal: no checkout row exists, so map by verified customer email.
  if p_customer_email is null or p_customer_email = '' then
    raise exception 'cannot map recurring payment to customer';
  end if;
  select u.id into target_user_id from auth.users u
    where lower(u.email) = lower(p_customer_email) limit 1;
  if target_user_id is null then raise exception 'customer account not found'; end if;

  select monthly_video_credits into credit_count from public.profiles where id = target_user_id for update;
  if credit_count is null or credit_count <= 0 then raise exception 'monthly credit allowance is not configured'; end if;
  expected_amount := coalesce(nullif(current_setting('app.alixvi_monthly_price_rwf', true), '')::integer, 3000);
  if round(p_amount)::integer <> expected_amount then raise exception 'recurring amount does not match monthly price'; end if;

  insert into public.payments(user_id, tx_ref, provider_transaction_id, payment_method, amount_rwf, credits_granted, status, paid_at)
  values (target_user_id, 'flw-recurring-' || p_transaction_id, p_transaction_id,
          'card', round(p_amount)::integer, credit_count, 'successful', now())
  on conflict do nothing
  returning id into inserted_id;

  if inserted_id is null then
    return jsonb_build_object('applied', false, 'reason', 'already_applied');
  end if;

  update public.profiles
    set subscription_status = 'active',
        paid_video_credits = paid_video_credits + credit_count,
        subscription_renews_at = now() + interval '1 month',
        updated_at = now()
    where id = target_user_id;
  return jsonb_build_object('applied', true, 'user_id', target_user_id, 'credits', credit_count);
end;
$$;

revoke all on function public.apply_verified_flutterwave_payment(text, text, numeric, text, text) from public, anon, authenticated;
grant execute on function public.apply_verified_flutterwave_payment(text, text, numeric, text, text) to service_role;


create or replace function public.set_flutterwave_subscription_state(p_customer_email text, p_state text)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare target_user_id uuid;
begin
  if auth.role() <> 'service_role' then raise exception 'service role required'; end if;
  if p_state not in ('past_due','cancelled') then raise exception 'invalid subscription state'; end if;
  select id into target_user_id from auth.users where lower(email) = lower(p_customer_email) limit 1;
  if target_user_id is null then return; end if;
  update public.profiles set subscription_status = p_state, updated_at = now() where id = target_user_id and subscription_status = 'active';
end;
$$;
revoke all on function public.set_flutterwave_subscription_state(text, text) from public, anon, authenticated;
grant execute on function public.set_flutterwave_subscription_state(text, text) to service_role;

-- Enforce monthly membership expiry even if a provider webhook is delayed.
create or replace function public.consume_video_credit()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare p public.profiles%rowtype;
begin
  if auth.uid() is null then return jsonb_build_object('allowed', false, 'reason', 'sign_in_required'); end if;
  select * into p from public.profiles where id = auth.uid() for update;
  if not found then return jsonb_build_object('allowed', false, 'reason', 'profile_missing'); end if;

  if p.trial_videos_remaining > 0 then
    update public.profiles set trial_videos_remaining = trial_videos_remaining - 1, updated_at = now() where id = auth.uid();
    return jsonb_build_object('allowed', true, 'source', 'trial', 'remaining', p.trial_videos_remaining - 1);
  end if;

  if p.subscription_status = 'active' and p.subscription_renews_at is not null and p.subscription_renews_at <= now() then
    update public.profiles set subscription_status = 'past_due', updated_at = now() where id = auth.uid();
    return jsonb_build_object('allowed', false, 'reason', 'subscription_expired');
  end if;

  if p.subscription_status = 'active' and p.subscription_renews_at > now() and p.paid_video_credits > 0 then
    update public.profiles set paid_video_credits = paid_video_credits - 1, updated_at = now() where id = auth.uid();
    return jsonb_build_object('allowed', true, 'source', 'paid', 'remaining', p.paid_video_credits - 1);
  end if;
  return jsonb_build_object('allowed', false, 'reason', 'credits_required');
end;
$$;
revoke all on function public.consume_video_credit() from public;
grant execute on function public.consume_video_credit() to authenticated;
