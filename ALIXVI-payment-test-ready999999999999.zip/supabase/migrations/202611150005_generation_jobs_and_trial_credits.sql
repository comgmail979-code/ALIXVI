-- Connect the existing ALIXVI video-generation API to the current
-- alixvi_* billing schema. Do not apply the older 001-003 legacy migrations.

create table if not exists public.generation_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider_request_id text not null unique,
  model text not null,
  scene_number integer not null default 1 check (scene_number between 1 and 100),
  credit_source text not null check (credit_source in ('trial','subscription')),
  credit_refunded boolean not null default false,
  status text not null default 'IN_QUEUE',
  video_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists generation_jobs_user_created_idx
  on public.generation_jobs(user_id, created_at desc);
alter table public.generation_jobs enable row level security;
revoke all on public.generation_jobs from anon;
grant select on public.generation_jobs to authenticated;
grant all on public.generation_jobs to service_role;
drop policy if exists "Users can read own generation jobs" on public.generation_jobs;
create policy "Users can read own generation jobs"
  on public.generation_jobs for select to authenticated
  using ((select auth.uid()) = user_id);

-- Lock the profile row so two simultaneous generation requests cannot both
-- spend the same final free trial. Paid subscriptions allow generation until
-- the paid-through date; cancellation does not revoke already-paid access.
create or replace function public.consume_video_credit()
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_user uuid := auth.uid();
  used_count integer;
  active_until timestamptz;
begin
  if target_user is null then
    return jsonb_build_object('allowed', false, 'reason', 'sign_in_required');
  end if;

  select free_videos_used into used_count
  from public.alixvi_profiles
  where user_id = target_user
  for update;

  if not found then
    return jsonb_build_object('allowed', false, 'reason', 'profile_missing');
  end if;

  if used_count < 2 then
    update public.alixvi_profiles
      set free_videos_used = free_videos_used + 1, updated_at = now()
      where user_id = target_user;
    return jsonb_build_object(
      'allowed', true,
      'source', 'trial',
      'remaining', greatest(0, 1 - used_count)
    );
  end if;

  select current_period_end into active_until
  from public.alixvi_subscriptions
  where user_id = target_user
    and status in ('active', 'cancelled')
    and current_period_end > now()
  order by current_period_end desc
  limit 1;

  if active_until is not null then
    return jsonb_build_object(
      'allowed', true,
      'source', 'subscription',
      'remaining', null,
      'subscription_valid_until', active_until
    );
  end if;

  return jsonb_build_object('allowed', false, 'reason', 'credits_required');
end;
$$;

revoke all on function public.consume_video_credit() from public, anon;
grant execute on function public.consume_video_credit() to authenticated;

-- A failed provider submission restores only a trial that was consumed.
-- Subscription access is time-based and therefore does not need a refund.
create or replace function public.refund_video_credit(p_user_id uuid, p_source text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role' then
    raise exception 'service role required';
  end if;
  if p_source = 'trial' then
    update public.alixvi_profiles
      set free_videos_used = greatest(0, free_videos_used - 1), updated_at = now()
      where user_id = p_user_id;
  elsif p_source = 'subscription' then
    return;
  else
    raise exception 'invalid credit source';
  end if;
end;
$$;
revoke all on function public.refund_video_credit(uuid, text) from public, anon, authenticated;
grant execute on function public.refund_video_credit(uuid, text) to service_role;

-- Lock and mark a failed job before restoring its trial, making repeated
-- status polling idempotent and preventing multiple refunds for one render.
create or replace function public.refund_failed_generation(p_job_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  job_row public.generation_jobs%rowtype;
begin
  if coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role' then
    raise exception 'service role required';
  end if;

  select * into job_row
  from public.generation_jobs
  where id = p_job_id
  for update;

  if not found or job_row.credit_refunded or job_row.status = 'COMPLETED' then
    return;
  end if;

  if job_row.credit_source = 'trial' then
    update public.alixvi_profiles
      set free_videos_used = greatest(0, free_videos_used - 1), updated_at = now()
      where user_id = job_row.user_id;
  end if;

  update public.generation_jobs
    set credit_refunded = true, status = 'FAILED', updated_at = now()
    where id = p_job_id;
end;
$$;
revoke all on function public.refund_failed_generation(uuid) from public, anon, authenticated;
grant execute on function public.refund_failed_generation(uuid) to service_role;
