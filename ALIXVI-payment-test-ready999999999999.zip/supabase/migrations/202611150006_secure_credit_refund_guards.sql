-- Harden service-role checks against a missing JWT role claim.
create or replace function public.refund_video_credit(p_user_id uuid, p_source text)
returns void language plpgsql security definer set search_path = ''
as $$
begin
  if coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role' then
    raise exception 'service role required';
  end if;
  if p_source = 'trial' then
    update public.alixvi_profiles
      set free_videos_used = greatest(0, free_videos_used - 1), updated_at = now()
      where user_id = p_user_id;
  elsif p_source = 'subscription' then
    return;
  else
    raise exception 'invalid credit source';
  end if;
end;
$$;

create or replace function public.refund_failed_generation(p_job_id uuid)
returns void language plpgsql security definer set search_path = ''
as $$
declare job_row public.generation_jobs%rowtype;
begin
  if coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role' then
    raise exception 'service role required';
  end if;
  select * into job_row from public.generation_jobs where id = p_job_id for update;
  if not found or job_row.credit_refunded or job_row.status = 'COMPLETED' then return; end if;
  if job_row.credit_source = 'trial' then
    update public.alixvi_profiles
      set free_videos_used = greatest(0, free_videos_used - 1), updated_at = now()
      where user_id = job_row.user_id;
  end if;
  update public.generation_jobs
    set credit_refunded = true, status = 'FAILED', updated_at = now()
    where id = p_job_id;
end;
$$;
revoke all on function public.refund_video_credit(uuid, text) from public, anon, authenticated;
grant execute on function public.refund_video_credit(uuid, text) to service_role;
revoke all on function public.refund_failed_generation(uuid) from public, anon, authenticated;
grant execute on function public.refund_failed_generation(uuid) to service_role;
