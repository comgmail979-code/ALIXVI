-- Preserve paid access until the end of the already-paid monthly period.
-- Run after migrations 001 and 002.
create or replace function public.consume_video_credit()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare p public.profiles%rowtype;
begin
  if auth.uid() is null then
    return jsonb_build_object('allowed', false, 'reason', 'sign_in_required');
  end if;

  select * into p from public.profiles where id = auth.uid() for update;
  if not found then
    return jsonb_build_object('allowed', false, 'reason', 'profile_missing');
  end if;

  -- Trial allowance remains available independently of paid membership.
  if p.trial_videos_remaining > 0 then
    update public.profiles
      set trial_videos_remaining = trial_videos_remaining - 1, updated_at = now()
      where id = auth.uid();
    return jsonb_build_object('allowed', true, 'source', 'trial', 'remaining', p.trial_videos_remaining - 1);
  end if;

  -- A cancelled or past-due membership keeps access only through its paid-through date.
  if p.subscription_status in ('active','cancelled')
     and p.subscription_renews_at is not null
     and p.subscription_renews_at > now()
     and p.paid_video_credits > 0 then
    update public.profiles
      set paid_video_credits = paid_video_credits - 1, updated_at = now()
      where id = auth.uid();
    return jsonb_build_object('allowed', true, 'source', 'paid', 'remaining', p.paid_video_credits - 1);
  end if;

  if p.subscription_status in ('active','cancelled')
     and p.subscription_renews_at is not null
     and p.subscription_renews_at <= now() then
    update public.profiles set subscription_status = 'past_due', updated_at = now() where id = auth.uid();
    return jsonb_build_object('allowed', false, 'reason', 'subscription_expired');
  end if;

  return jsonb_build_object('allowed', false, 'reason', 'credits_required');
end;
$$;

revoke all on function public.consume_video_credit() from public;
grant execute on function public.consume_video_credit() to authenticated;
