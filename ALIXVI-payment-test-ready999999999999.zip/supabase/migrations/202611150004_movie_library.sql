-- Per-user saved movie timelines. This stores the project structure and source
-- video URLs; it does not store the exported MP4 binary.
create table if not exists public.movie_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 100),
  scenes jsonb not null check (jsonb_typeof(scenes) = 'array' and jsonb_array_length(scenes) between 2 and 20),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists movie_projects_user_updated_idx on public.movie_projects(user_id, updated_at desc);
alter table public.movie_projects enable row level security;
drop policy if exists "Users can read own movie projects" on public.movie_projects;
create policy "Users can read own movie projects" on public.movie_projects for select using (auth.uid() = user_id);
drop policy if exists "Users can create own movie projects" on public.movie_projects;
create policy "Users can create own movie projects" on public.movie_projects for insert with check (auth.uid() = user_id);
drop policy if exists "Users can delete own movie projects" on public.movie_projects;
create policy "Users can delete own movie projects" on public.movie_projects for delete using (auth.uid() = user_id);
