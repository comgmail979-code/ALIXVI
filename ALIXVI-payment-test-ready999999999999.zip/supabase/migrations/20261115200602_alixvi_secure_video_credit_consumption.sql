drop function if exists public.consume_video_credit();

create or replace function public.consume_video_credit(p_user_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_user uuid := p_user_id;
  used_count integer;
  active_until timestamptz;
begin
  if coalesce(current_setting('request.jwt.claim.role', true), '') <> 'service_role' then
    raise exception 'service role required';
  end if;
  if target_user is null then
    raise exception 'user id required';
  end if;

  select free_videos_used into used_count
  from public.alixvi_profiles
  where user_id = target_user
  for update;

  if not found then
    return jsonb_build_object('allowed', false, 'reason', 'profile_missing');
  end if;

  if used_count < 2 then
    update public.alixvi_profiles
      set free_videos_used = free_videos_used + 1, updated_at = now()
      where user_id = target_user;
    return jsonb_build_object('allowed', true, 'source', 'trial', 'remaining', greatest(0, 1 - used_count));
  end if;

  select current_period_end into active_until
  from public.alixvi_subscriptions
  where user_id = target_user
    and status in ('active', 'cancelled')
    and current_period_end > now()
  order by current_period_end desc
  limit 1;

  if active_until is not null then
    return jsonb_build_object('allowed', true, 'source', 'subscription', 'remaining', null,
      'subscription_valid_until', active_until);
  end if;

  return jsonb_build_object('allowed', false, 'reason', 'credits_required');
end;
$$;

revoke all on function public.consume_video_credit(uuid) from public, anon, authenticated;
grant execute on function public.consume_video_credit(uuid) to service_role;
