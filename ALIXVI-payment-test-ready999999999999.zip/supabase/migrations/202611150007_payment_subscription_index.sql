-- Cover the payment -> subscription foreign key for efficient lookups/deletes.
create index if not exists alixvi_payments_subscription_id_idx
  on public.alixvi_payments(subscription_id)
  where subscription_id is not null;
